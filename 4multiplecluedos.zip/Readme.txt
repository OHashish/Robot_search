This files should be put in .gazebo/models. Also check, if all files from world/model are in .gazebo/models
